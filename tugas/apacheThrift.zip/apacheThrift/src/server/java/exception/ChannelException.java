package exception;

/**
 * Created by nim_13512065 on 9/17/15.
 */
public class ChannelException extends Exception {
    public ChannelException(String string) {
        super(string);
    }
}
