package filter;

/**
 * Created by nim_13512065 on 9/17/15.
 */
public @interface ValidUserId {

}
